import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;
/**
 * The Coin actor is inserted in the gumball machine whenever user drags it towards the slot !
 * 
 * @author (Gagan Jain) 
 * @version (9/18/16)
 */
public class Coin extends Actor
{
    
    public void act() 
    {
        int mouseX, mouseY ;
        World world = getWorld();
        
        if(Greenfoot.mouseDragged(this)) {
            
          /*List<Message> list = world.getObjects(Message.class);
          if( list != null)
          {
             int size = list.size();
             for(int i=0; i<size; i++)
             {
                 world.removeObject(list.get(i));
             } 
          }*/
          world.removeObjects(world.getObjects(Message.class));
          world.removeObjects(world.getObjects(Gumball.class));
          
            MouseInfo mouse = Greenfoot.getMouseInfo();  
            mouseX=mouse.getX();  
            mouseY=mouse.getY();  
            setLocation(mouseX, mouseY);
            if ( mouseX >= 365  && mouseY >= 277 )
            {
                GumballMachine gumballMachine;
                gumballMachine = (GumballMachine) getOneObjectAtOffset(0, 0, GumballMachine.class);
                gumballMachine.insertCoin(this);
            }
            
        }   
    }
    
   
        
      
    
    
}
