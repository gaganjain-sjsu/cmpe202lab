import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * The RandomPicker alien randomly picks a gumball from the machine and adds it to the world..
 * 
 * @author (Gagan Jain) 
 * @version (9/18/16)
 */
public class RandomPicker extends Picker
{
    /**
     * Act - do whatever the RandomPicker wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    Message message;
    
    public void act() 
    {
        // Add your action code here.
    }    
    
    public void pickGumball()
    {
       World world = getWorld();
       int randomNumber = Greenfoot.getRandomNumber(3);
        //Pick redGumball if randomNumber = 0
        //Pick blueGumball if randomNumber = 1
        //Pick greenGumballl if randomNumber = 2
            if ( randomNumber == 0 )
            {
                
                message = new Message("Red Gumball");
                world.addObject(message,670, 94);
                //world.showText("Red Gumball",655,94);
                world.addObject(new RedGumball(),550, 94); 
            }
        
            else if(randomNumber == 1 )
            {
                message = new Message("Blue Gumball");
                world.addObject(message,670, 94);
                //world.showText("Blue Gumball",655,94);
                world.addObject(new BlueGumball(),550, 94); 
            }
            
            else
            
            {
                message = new Message("Green Gumball");
                world.addObject(message,670, 94);
                //world.showText("Blue Gumball",655,94);
                world.addObject(new GreenGumball(),550, 94); 
            }    
    }
    
}
