import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * Whenever a quarter is inserted, the machine calls the Inspector to inspect the coin. 
 * The Inspector then randomly assigns the task to an alien to eject a gumball.
 * 
 * @author (Gagan Jain) 
 * @version (9/18/16)
 */
public class Inspector extends Alien
{
    /**
     * Act - do whatever the Inspector wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    Message message; 
    public void act() 
    {
        // Add your action code here.
    }    
    
    public void inspectCoin(Coin coin)
    {
        //If the coin is a Fake Quarter => Display a message "Fake Quarter" 
        World world = getWorld();
        if( coin instanceof FakeQuarter )
        {
            message = new Message("Fake Quarter");
            world.addObject(message,533,291);
        }
        
        else if ( coin instanceof Penny )
        {
            //If the coin is a Penny => Display a message "Insert Quarter" 
            message = new Message("Penny");
            world.addObject(message,533,291);
        }
        
        else
        {
            //If the coin is a Quarter => Display a message "Quarter Inserted" and 
            // randomly pick an alien to eject a gumball
            message = new Message("Quarter Inserted");
            world.addObject(message,533,291);
           
            int randomNumber = Greenfoot.getRandomNumber(2);
            //Assign work to GreenPicker if randomNumber = 0
            //Assign work to RandomPicker if randomNumber = 1
            if ( randomNumber == 0 )
            {
                
                Picker picker = world.getObjects(GreenPicker.class).get(0);
                picker.pickGumball();
            }
        
            else
            {
                
                Picker picker = world.getObjects(RandomPicker.class).get(0);
                picker.pickGumball();
            }
        }
        
         
        
    }
    
}
