import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;
/**
 * The Gumball Machine is supposed to eject a gumball when a quarter is inserted !
 * 
 * @author (Gagan Jain) 
 * @version (9/18/16)
 */
public class GumballMachine extends Actor
{
    Inspector inspector;
    Coin coin;
    Boolean isCoinInserted = false;
    Message message;
    //Message message1;
    int gumballCount;
    //int x = 0;
    public GumballMachine()
    {
        GreenfootImage image = getImage() ;
        image.scale( 350, 400 ) ; 
        gumballCount = 5;
        message = new Message();
    }

    public void act() 
    {
       // The Gumball Machine acts as following when the user clicks on the machine :
       // When Coin is not inserted => It displays a message "Insert Quarter"
       // When Coin is inserted  => It calls turnCrank() method.
       // When the machine is out of gumballs => It displays a message "Out of Gumballs"
       World world = getWorld();
       
       if(Greenfoot.mousePressed(this))
       {
          if( gumballCount > 0 && !isCoinInserted)
          {
             world.removeObjects(world.getObjects(Message.class));
             world.removeObjects(world.getObjects(Gumball.class));
             message.setText("Insert Quarter");// = new Message("Insert Quarter");
             world.addObject(message, 367,237); 
          } 
          
          else if(gumballCount == 0)
          {
             
             world.removeObjects(world.getObjects(Message.class));
             world.removeObjects(world.getObjects(Gumball.class));
             message.setText("Sorry! Out of Gumballs");// = new Message("Sorry! Out of Gumballs");
             world.addObject(message, 367,237);
             
             //world.removeObject(coin);
             //world.addObject(coin, 68+x, 156); 
             //x += 100;
          }
          
          else
          {
              turnCrank();
          }
              
          
       }
       
        
       
    }
    
    public void insertCoin(Coin coin)
    {
       
      //When user inserts coin in the machine, the Gumball machine consumes the coin if no coin is present
      //and displays a message "Have Coin";
      // If the machine is out of gumballs, it displays a message "Out of Gumballs"
      
     
      World world = getWorld();
      if (coin != null)
      {
           
       if( gumballCount > 0 && !isCoinInserted)
       {
           message.setText("Have Coin");// = new Message("Have Coin");
           this.coin = coin;
           world.removeObject(coin);
           world.addObject(message, 367,237);
           //world.showText("Have Coin",367, 237);
           isCoinInserted = true;
       }
       
       else if( gumballCount == 0)
       {
           message.setText("Sorry! Out of Gumballs");// = new Message("Sorry! Out of Gumballs");
           world.addObject(message, 367,237);
           //world.removeObject(coin);
           //world.addObject(coin, 68+x, 400);
           //x += 100;
       }
       else
       {
         //Commenting as the machine should not consume a new coin when coin is already inserted  
        /*if( coin instanceof FakeQuarter )
            {
            //message = new Message("Fake Quarter");
            //world.addObject(message,533,291);
            //world.showText("Fake Quarter",533,291);
            world.removeObject(coin);
            world.addObject(coin, 66, 248);
           }
        
        else if ( coin instanceof Penny )
        {
            //message = new Message("Insert Quarter");
            //world.addObject(message,533,291);
            //world.showText("Insert Quarter",533,291);
            world.removeObject(coin);
            world.addObject(coin, 57, 71);
        }
        
        else
        {
           // message = new Message("Quarter Inserted");
           // world.addObject(message,533,291);
           world.removeObject(coin);
           world.addObject(coin, 68, 156);
        }*/
           message.setText("Coin is inserted already"); //= new Message("Coin is inserted already");
           world.addObject(message, 367,237);
           
       }
      }
      
    }
        
    public void turnCrank()
    {
        //When user clicks on the machine and coin in present in the system, 
        //the machine displays a messgage "Crank Turned" and calls out for an inspector to inspect the coin
        
        World world = getWorld();
        message.setText("Crank Turned!");
        gumballCount -= 1;
        
        inspector = world.getObjects(Inspector.class).get(0);
        if ( inspector != null )
        {
            inspector.inspectCoin(coin);
        } 
        isCoinInserted = false;
        
    }
        
            
}     
       
        
        
        
        