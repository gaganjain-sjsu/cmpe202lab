import greenfoot.*;// (World, Actor, GreenfootImage, Greenfoot and MouseInfo) 
import java.awt.Color; 

/**
 * The Message Actor is supposed to display an appropriate text whenever required by any other actor.
 * 
 * @author (Gagan Jain) 
 * @version (9/18/16
 */
public class Message extends Actor
{
    /**
     * Act - do whatever the Message wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }   
    
    
    public Message()
    {
        updateImage("");
    }
     
    public Message(String text)
    {
        updateImage(text);
    }
     
    public void setText(String text)
    {
        updateImage(text);
    }
     
    private void updateImage(String text)
    {
        setImage(new GreenfootImage(text, 25, Color.black, Color.yellow));
    }
}

