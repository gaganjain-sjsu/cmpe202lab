import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * The GreenPicker alien always picks up a green gumball from the machine and adds it to the world.
 * 
 * @author (Gagan Jain) 
 * @version (9/18/16)
 */
public class GreenPicker extends Picker
{
    /**
     * Act - do whatever the GreenPicker wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    Message message;
    public void act() 
    {
        // Add your action code here.
    }    
    
    public void pickGumball()
    {
        World world = getWorld();
        message = new Message("Green Gumball");
        world.addObject(message,669, 456);
        //world.showText("Green Gumball",669,456);
        world.addObject(new GreenGumball(),550, 456); 
    }
}
